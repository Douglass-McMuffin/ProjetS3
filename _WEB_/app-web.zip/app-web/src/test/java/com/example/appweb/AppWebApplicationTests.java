package com.example.appweb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppWebApplicationTests {

	@Test
	void contextLoads() {
	}

}
